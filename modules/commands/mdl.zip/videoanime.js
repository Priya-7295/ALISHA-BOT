const axios = require("axios");
module.exports.config = {
    name: "video chill",
    version: "1.0.p",
    hasPermssion: 0,
    credits: "Gấu đẹp trai ",
    description: "noprefix",
    commandCategory: "Noprefix",
    usages: "",
    cooldowns: 0,
    denpendencies: {
        "axios": "",
        "moment-timezone": ""
    }
}

module.exports.handleEvent = async ({ event, api,Users }) => {
  const res = await axios.get('https://vitieubao.click/images/videochill');
  const data = res.data.url;
  let download = (await axios.get(data, {
      responseType: "stream"
    })).data;
  const moment = require("moment-timezone");
  const hours = moment.tz('Asia/Ho_Chi_Minh').format('HHmm');
  const session = (hours > 2401 && hours <= 400 ? "Video này chill phết :3" : hours > 401 && hours <= 700 ? "Anime Chill nè :)) " : hours > 701 && hours <= 1000 ? "😘K chill chặt cu 🙄 " : hours > 1001 && hours <= 1200 ? "😘Lại kêu k chill🙄 " : hours > 1201 && hours <= 1700 ? "😘Video này chill phết 🙄 " : hours > 1701 && hours <= 1800 ? "😘A li me của bạn 🙄" : hours > 1801 && hours <= 2400 ? "😘A li me chiu ne🙄" : "😘chill 🙄 ")
  let name = await Users.getNameUser(event.senderID)
  var msg = {body: ` ${session}, `, attachment: download}
  if (event.body.toLowerCase() == "chill"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "video chill"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "Anime chill"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "Chill"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "anime"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "vdanime"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "video chill"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "chill"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "video anime"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "Anime"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
  if (event.body.toLowerCase() == "chill quá"){
        return api.sendMessage(msg,event.threadID,event.messageID);}
        };
module.exports.run = async ({ event, api }) => {
return api.sendMessage("𝐃𝐮̀𝐧𝐠 𝐬𝐚𝐢 𝐜𝐚́𝐜𝐡 𝐫𝐨̂̀𝐢 𝐥𝐞̂𝐮 𝐥𝐞̂𝐮",event.threadID)
}